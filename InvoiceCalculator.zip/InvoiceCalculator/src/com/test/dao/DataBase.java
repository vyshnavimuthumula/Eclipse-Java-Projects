package com.test.dao;

import java.util.ArrayList;

import com.test.bean.Invoice;
import com.test.presentationlayer.DisplayOutput;
import com.test.servicelayer.Services;

public class DataBase implements InvoiceRepo {
	public static void storeData(Invoice inv) {
		ArrayList<String> arraylist = new ArrayList<String>();
		System.out.println("Invoice details are ");
		arraylist.add("Weight : " + inv.getWeight());
		arraylist.add("Distance : " + inv.getDistance());
		arraylist.add("CGST : " + inv.getCgst());
		arraylist.add("SGST : " + inv.getSgst());
		arraylist.add("Transctioncharges : " + inv.getAmount());
		//System.out.println(arraylist);
		Services s = new Services();
		s.move(arraylist);
	}
}
