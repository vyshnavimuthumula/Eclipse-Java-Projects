//public int test()
//    {
//        //testing weight
//        int x=a1.validateWeight(2);
//        assertEquals(1,x);
//        int y=a1.validateWeight(5);
//        assertEquals(1,y);
//        int z=a1.validateWeight(10);
//        assertEquals(1,z);
//    }
//public int test()
//{
//    //testing weight
//    int x=a1.validatedistance(2);
//    assertEquals(1,x);
//    int y=a1.validatedistance(5);
//    assertEquals(1,y);
//    int z=a1.validatedistance(10);
//    assertEquals(1,z);
//}