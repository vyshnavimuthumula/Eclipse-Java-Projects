package com.test.dao;

public interface InvoiceRepo {

}
