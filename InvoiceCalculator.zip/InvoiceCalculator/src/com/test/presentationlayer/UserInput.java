package com.test.presentationlayer;

import java.util.Scanner;

import com.test.bean.Invoice;
import com.test.servicelayer.InvoiceService;
import com.test.servicelayer.Services;

public class UserInput {
	public void acceptData() {
		// TODO Auto-generated method stub
		//Create object for bean class
		Invoice inv = new Invoice();
		int weight;
		int distance;
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter weight in KG's ");
		weight = sc.nextInt();
		inv.setWeight(weight);
		
		System.out.println("Enter distance in KM's ");
		distance = sc.nextInt();
		inv.setDistance(distance);
		sc.close();
		//Move user input to service layer by creating an object for service layer with an interface
		
		InvoiceService calcservice = new Services();
		calcservice.calculateInvoice(inv);
		
	}

}
