package com.test.presentationlayer;

import java.util.Scanner;

public class MainClass {
	public static void main(String args[]) {
		int n;
		System.out.println("Invoice Calculator ");
		System.out.println("1. Enter calculator details ");
		System.out.println("2. Display details ");
		System.out.println("3. Exit ");
		Scanner sc = new Scanner(System.in);
		n = sc.nextInt();
		switch(n) {
		case 1 :
			UserInput ui = new UserInput();
			ui.acceptData();
			break;
		case 2 :
			DisplayOutput display = new DisplayOutput();
			display.showOutput(null);
			break;
		case 3 : 
			System.exit(0);
		default :
			System.out.println("Enter valid option");
		}
		sc.close();
	}
}
