package com.test.servicelayer;

import com.test.bean.Invoice;

public interface InvoiceService {

	void calculateInvoice(Invoice inv);
		
}
