package com.test.servicelayer;
import java.util.ArrayList;
import com.test.bean.Invoice;
import com.test.dao.DataBase;
import com.test.presentationlayer.DisplayOutput;
public class Services implements InvoiceService{
	    //validation		
	public void calculateInvoice(Invoice inv) {		
		int transcharges;
		transcharges = 2 * inv.getWeight()+inv.getDistance();
		double cgst,sgst;
		
		if(valweight1(inv.getWeight())==1) {
			if(valDistance(inv.getDistance())==1) {
		cgst = (transcharges * (0.35));
		inv.setCgst(cgst);
		sgst = (transcharges * (0.35));
		inv.setCgst(sgst);
		double amount = cgst + sgst;
		inv.setAmount(amount);
		}
		}
		//Transferring services to dao layer 
		DataBase dobj = new DataBase();
		dobj.storeData(inv);		
		
	}	
		private int valDistance(int distance) {
		// TODO Auto-generated method stub				
	    	if(distance<100)
	    		return 1;
	    	else
	    		return 0;
		}
		private int valweight1(int weight) {
			// TODO Auto-generated method stub
				if(weight>1)
					return 1;
				else
					return 0;
								  
		}
		public void move(ArrayList<String> arraylist) {
			// TODO Auto-generated method stub
			DisplayOutput obj1 = new DisplayOutput();
			obj1.showOutput(arraylist);
			
		}
	
	
}
