
public class SampleTest {
	String s="hello";
	void getDate() {
		//System.out.println("get");
		s="hi";
		}
	void putDate() {
		System.out.println("put" + s);
	}
	static void printDate() {
		System.out.println("staticprintData" );
		//putDate();
		}

public static void main(String args[]) {
	SampleTest st1 = new SampleTest();
	SampleTest st2 = new SampleTest();
	st1.getDate();
	st2.putDate();
	//st.getDate();
}
}