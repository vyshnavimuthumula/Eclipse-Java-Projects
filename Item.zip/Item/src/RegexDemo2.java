import java.util.regex.*;
public class RegexDemo2 {
public static void main(String args[]) {
	String regex= "you";
	String text = "welcome to you vyshu you";
	Pattern pattern = Pattern.compile(regex);//static bcz P is capital
	Matcher matcher = pattern.matcher(text);//Non static bcz lowercase p
	int c=0;
	while(matcher.find()) {
		c++;
		System.out.println("found = "+ c + ":" + matcher.start() + " - " + matcher.end());
}
}
}