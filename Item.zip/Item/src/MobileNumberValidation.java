import java.util.regex.*;
public class MobileNumberValidation {
	public static void main(String args[]) {
		String mobileNo = "918925052525";
		if(mobileNo.matches("(\\+91(-)?|91(-)?|0(-)?)?((9)|(8)|(7))[0-9]{9}"))
			System.out.println("valid");
		else
			System.out.println("invalid");
		
	}
}
