
public class ThrowException {

}
