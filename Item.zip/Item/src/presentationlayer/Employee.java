package presentationlayer;

public class Employee {
public static void main(String args[]) {
	int empid;
	String name;
	
}
}
