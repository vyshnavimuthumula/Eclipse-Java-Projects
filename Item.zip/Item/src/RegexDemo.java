import java.util.regex.*;
public class RegexDemo {
public static void main(String args[]) {
	String regex= ".*regex.*";
	String text = "regex";
	boolean matches = Pattern.matches(regex, text); //matches method accepts two arguments
			System.out.println("matches = "+ matches);
}
}
