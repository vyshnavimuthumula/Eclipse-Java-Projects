//import java.util.regex.*;
public class NameValidation {
	public static void main(String args[]) {
		String name = "d";
		String mobileNo = "918501804512";
		if(name.matches("[^abc]"))
			System.out.println("valid name");
		else
			System.out.println("invalid name");
		if(mobileNo.matches("(\\+91(-)?|91(-)?|0(-)?)?((9)|(8)|(7))[0-9]{9}"))
			System.out.println("valid");
		else
			System.out.println("invalid");
		
	}
}
