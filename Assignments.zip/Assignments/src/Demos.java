import java.util.regex.Pattern;

public class Demos {
      
      public static int main(String[] args) {
       String input = "Hello Welcome";
       String pattern = "\\sHello\\sWelcome\\s";
       boolean flag = Pattern.matches(pattern, input);
       System.out.println("hi");
	return 0;
      }
}