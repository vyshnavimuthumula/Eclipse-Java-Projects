package com.pre;
import java.util.ArrayList;
import java.util.Scanner;
import com.bean.*;
import com.serve.Service; 

public class Main {
    public static void main(String args[])
    {
        System.out.println("Student Grades");
        System.out.println("1. Enter Details\n2. Display details\n3. Calculate percentage\n4. Exit");
        int n;
        Scanner sc = new Scanner(System.in);
        n=sc.nextInt();
       // ArrayList<String> a = new ArrayList<String>();
        //a=null;
        switch(n)
        {
        case 1: UserInput ui = new UserInput();
                ui.userInput();
                break;
        case 2: Output op = new Output();
                op.outputDisplay(null);
                break;
        
        case 3: 
        		System.exit(0);
        default:
        		System.out.println("Invalid option");
        }
        sc.close();
    }

 

}
 