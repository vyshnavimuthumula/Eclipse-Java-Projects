package com.serve;
import java.util.ArrayList;
import com.bean.StudentMarks;
import com.dao.*;
import com.pre.*;
public class Service {
    public void calculate(StudentMarks sm) {
        int percent;
        percent=(sm.getMaths()+sm.getChem()+sm.getPhysics())/3;
        Database db = new Database();
        db.store(sm,percent);
    }
    public void transfer(ArrayList<String> a)
    {
        Output op= new Output();
        op.outputDisplay(a);
    }


}