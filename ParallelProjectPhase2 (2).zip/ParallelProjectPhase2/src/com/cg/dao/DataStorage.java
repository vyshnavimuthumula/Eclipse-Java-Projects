package com.cg.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.cg.bean.Bank;
import com.cg.bean.Transaction;

public class DataStorage {

	Bank bank = new Bank();
	Transaction transaction = new Transaction();
	String URL = "JDBC:oracle:thin:@localhost:1521:XE";

	public Connection establishconn() {
		Connection connect = null;
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver"); // to load the driver
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			connect = DriverManager.getConnection(URL, "system", "orcl11g");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return connect;
	}

	// Storing the data
	public void storeCustomerDetails(Bank bank) {
		Connection con = establishconn();
		int result = 0;
		try {
			PreparedStatement stat = con.prepareStatement("insert into bankapp values(?,?,?,?,?,?)");
			PreparedStatement state = con.prepareStatement("insert into Transactions values(?,?,?,?,?)");

			stat.setString(1, bank.getName());
			stat.setString(2, bank.getAdharNum());
			stat.setString(3, bank.getPhoneNum());
			stat.setInt(4, bank.getAccnum());
			stat.setInt(5, bank.getPin());
			stat.setInt(6, bank.getBalance());
			result = stat.executeUpdate();
			System.out.println(result);
			System.out.println(stat);

			transaction.setAccountnum(bank.getAccnum());
			transaction.setCredit(bank.getBalance());
			transaction.setDebit(0);
			transaction.setTotalbal(bank.getBalance());

			state.setInt(1, transaction.getAccountnum());
			state.setInt(2, 0);
			state.setInt(3, transaction.getDebit());
			state.setInt(4, transaction.getTotalbal());
			state.executeQuery();

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	public int showBalance(int bacc) {
		Connection con = establishconn();
		int result = 0;
		try {
			PreparedStatement stat = con.prepareStatement("select balance from bankapp where accountnum=?");
			stat.setLong(1, bacc);
			ResultSet rs = stat.executeQuery();
			while (rs.next()) {
				result = rs.getInt("balance");
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return result;
	}

	public int depositAmount(int accountnum, int Amount1) {
		Connection con = establishconn();
		int deposit = 0;
		try {
			int amount = showBalance(accountnum) + Amount1;
			PreparedStatement stat = con.prepareStatement("update bankapp set balance=? where accountnum=?");
			PreparedStatement state = con.prepareStatement("insert into transactions values(?,?,?,?,?)");
			stat.setInt(1, amount);
			stat.setInt(2, accountnum);
			stat.executeQuery();
			deposit = showBalance(accountnum);
			state.setInt(1, transaction.getAccountnum());
			state.setInt(2, transaction.getTotalbal());
			state.setInt(3, 0);
			state.setInt(4, transaction.getTotalbal());
			state.executeQuery();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return deposit;
	}

	public int withdraw(int accountnum, int Amount1) {
		Connection con = establishconn();
		int amount = showBalance(accountnum) - Amount1;
		int withdraw = 0;
		try {
			PreparedStatement stat = con.prepareStatement("update bankapp set balance=? where accountnum=?");
			stat.setLong(1, amount);
			stat.setLong(2, accountnum);
			stat.executeQuery();
			withdraw = showBalance(accountnum);

		} catch (SQLException e) {
			e.printStackTrace();
		}
		return withdraw;
	}

	public void fundTransfer(int senderacc, int receiveracc, int transferamt) {
		Connection con = establishconn();
		int amount = showBalance(senderacc) - transferamt;

		try {
			PreparedStatement stat = con.prepareStatement("update bankapp set balance=? where accountnum=?");
			stat.setLong(1, amount);
			stat.setLong(2, senderacc);
			stat.executeQuery();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		int amount1 = showBalance(receiveracc) + transferamt;
		try {
			PreparedStatement stat = con.prepareStatement("update bankapp set balance=? where accountnum=?");
			stat.setLong(1, amount1);
			stat.setLong(2, receiveracc);
			stat.executeQuery();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public ResultSet getAllTransactions(int accountnum) {
		ResultSet rs = null;
		Connection con = establishconn();
		try {
			PreparedStatement stat = con.prepareStatement("select * from transactions where accountnum=?");
			stat.setLong(1, accountnum);
			rs = stat.executeQuery();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return rs;
	}
}
