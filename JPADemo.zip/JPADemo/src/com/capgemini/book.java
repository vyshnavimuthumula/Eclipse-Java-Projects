package com.capgemini;

public class book {
	private int isbn;
	private String title;
	private int price;
	public int getIsbn() {
		return isbn;
	}
	public void setIsbn(int isbn) {
		this.isbn = isbn;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	@Override
	public String toString() {
		return "book [isbn=" + isbn + ", title=" + title + ", price=" + price + "]";
	}
}
