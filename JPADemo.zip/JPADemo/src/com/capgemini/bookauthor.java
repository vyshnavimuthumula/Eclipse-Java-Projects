package com.capgemini;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.persistence.Entity;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
@Entity
public class bookauthor {
	public static void main(String args[]) {
		String url = "jdbc:oracle:thin:@localhost:1521:XE";
		Author auth = new Author();
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection con=DriverManager.getConnection(url, "system", "orcl11g");
				PreparedStatement stat=con.prepareStatement("insert into author values(?,?,?,?,?)");
		
		stat.setInt(1, auth.getId());
		stat.setString(2, auth.getFirstName());
		stat.setString(3, auth.getLastname());
		stat.setString(4, auth.getMiddleName());
		stat.setInt(5, auth.getPhoneNo());
		int result = stat.executeUpdate();
		System.out.println(result +"record added");
		EntityManagerFactory factory=Persistence.createEntityManagerFactory("JPA-PU");
		EntityManager em = factory.createEntityManager();
		auth.setId(101);
		auth.setFirstName("vyshnavi");
		auth.setMiddleName("reddy");
		auth.setLastname("muthumula");
		auth.setPhoneNo(123456);
		
		em.getTransaction().begin();
		em.persist(auth);
		em.getTransaction().commit();
		}catch(ClassNotFoundException e) {
			e.printStackTrace();
		}catch(SQLException e) {
			e.printStackTrace();
		}
	}
}