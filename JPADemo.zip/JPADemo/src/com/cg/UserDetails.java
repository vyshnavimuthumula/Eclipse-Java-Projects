package com.cg;

import javax.persistence.Entity;

@Entity
public class UserDetails {
	private int id;
	private String name;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getId() {
		return id;
	}
	public void setId(int i) {
		// TODO Auto-generated method stub
		
	}
	

}
