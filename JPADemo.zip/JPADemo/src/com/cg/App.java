package com.cg;

import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class App {
	public static void main(String[] args) {
//		Scanner sc=new Scanner(System.in);
//
//	String url = "jdbc:oracle:thin:@localhost:1521:ORCL";
//	Employee emp=new Employee();
//	try {
//			Class.forName("oracle.jdbc.driver.OracleDriver");
//			System.out.println("Enter Id");
//			emp.setId(Integer.parseInt(sc.nextLine()));
//			Connection con=DriverManager.getConnection(url, "ere", "password")
//					Statement stat=co
//					PreparedStatement stat=con.prepareStatement("insert into employee_details values(?,?,?,?)");
//	}catch(ClassNotFoundException e) {
//		e.printStackTrace();
//		}catch(SQLException e) {
//			e.printStackTrace();
//		}
		UserDetails user = new UserDetails();
		user.setId(101);
		user.setName("Sunil");
		EntityManagerFactory factory=Persistence.createEntityManagerFactory("JPA-PU");
		EntityManager em = factory.createEntityManager();
		em.getTransaction().begin();
		em.persist(user);
		em.getTransaction().commit();
		System.out.println("data Saved");
	}
}
