/**
 * 
 */
package com.cg;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.capgemini.Author;

public class FindAuthor {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.print("welcome");
		EntityManagerFactory factory=Persistence.createEntityManagerFactory("JPA-PU");
		EntityManager em = factory.createEntityManager();
		em.getTransaction().begin();
		Author auth = new Author();
		auth.setId(101);
		auth.setFirstName("vyshnavi");
		auth.setMiddleName("reddy");
		auth.setLastname("muthumula");
		auth.setPhoneNo(123456);
		
	
		em.persist(auth);
		em.getTransaction().commit();
	}

}
