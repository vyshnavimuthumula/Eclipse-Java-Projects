package com.cg.bean;

public class Transaction {

	private int credit;
	private int debit;
	private int totalbal;
	private int accountnum;
	
	public int getCredit() {
		return credit;
	}
	public void setCredit(int credit) {
		this.credit = credit;
	}
	public int getDebit() {
		return debit;
	}
	public void setDebit(int debit) {
		this.debit = debit;
	}
	public int getTotalbal() {
		return totalbal;
	}
	public void setTotalbal(int totalbal) {
		this.totalbal = totalbal;
	}
	
	public int getAccountnum() {
		return accountnum;
	}
	public void setAccountnum(int accountnum) {
		this.accountnum = accountnum;
	}
	@Override
	public String toString() {
		return "Transaction [credit=" + credit + ", debit=" + debit + ", totalbal=" + totalbal + ", accountnum="
				+ accountnum + "]";
	}
	
	
//	public void printTransaction(Bank bank) {
//		
//		System.out.println(bank.getTransList());
//	}
	
}
