import java.util.function.BiFunction;
import java.util.function.Function;
interface Messageable{
	Message getMessage(String str);
}
class Message{
	Message(){
	}
		Message(String str){
			System.out.println(str);
		}
		int calclength(String str1) {
			return str1.length();
		}
}
public class MethodReferenceDemo {
public static void main(String args[]) {
	System.out.println(String.valueOf(65));
		Function<Integer,String>fun1=x->String.valueOf(x);
		System.out.println("Function1 "+ fun1.apply(10));
		Function<Integer,String>fun2=x->String.valueOf(x);
		System.out.println("Function2 " + fun2.apply(10));
		BiFunction<Integer,Integer,Integer>fun4 =Integer::sum;
		System.out.println(fun4.apply(2, 3));
		Messageable m= Message::new;
		m.getMessage("hi");
		Message mObj=new Message();
		Function<String,Integer> c = mObj::calclength;
		System.out.println(c.apply("hello"));
		BiFunction<Integer,Integer,Integer>fun3=(x,y) ->Integer.sum(x,y);
		System.out.println(fun3.apply(2,3));
		}
}

