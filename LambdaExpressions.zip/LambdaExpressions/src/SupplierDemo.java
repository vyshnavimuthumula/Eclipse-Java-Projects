import java.util.function.*;
public class SupplierDemo {
public static void main(String args[]) {
	IntSupplier supplier1 = () -> Integer.MAX_VALUE;
	System.out.println("MAX_VALUE" + supplier1.getAsInt());
	IntSupplier supplier2 = () -> Integer.MAX_VALUE;
	System.out.println("MAX_VALUE" + supplier2.getAsInt());
	int a=5;
	int b=9;
	IntSupplier supplier3=()->a*b;
	System.out.println(supplier3.getAsInt());
	IntSupplier supplier4=()->Integer.compare(a, b);
	System.out.println(supplier4.getAsInt());
			
	}
}
