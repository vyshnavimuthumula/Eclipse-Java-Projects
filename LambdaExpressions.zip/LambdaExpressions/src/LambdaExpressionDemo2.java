@FunctionalInterface
interface Sum2{
	int clacSum(int x,int y);
	
}
public class LambdaExpressionDemo2 {
public static void main(String args[]) {
	Sum2 s = (x,y)->x+y;
	int t=s.clacSum(5, 6);
	System.out.println(t);
}
}
