@FunctionalInterface
interface 
public class ConsumerDemo {

}
