@FunctionalInterface
interface Display2 {
	 int displen(String x);
}
public class LambdaExpressionDemo7 {
public static void main(String args[]) {
	Display2 t = x->x.length();
	int s = t.displen("hello");
	System.out.println(s);
	
}
}
