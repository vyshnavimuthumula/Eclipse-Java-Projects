@FunctionalInterface
interface Display {
	 int displen(String x);
}
public class LambdaExpressionDemo6 {
public static void main(String args[]) {
	Display t = (x)->x.length();
	int s = t.displen("hiii");
	System.out.println(s);
	
}
}