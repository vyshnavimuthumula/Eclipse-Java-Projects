@FunctionalInterface
interface min{
	int calcSum(int x,int y);
}
public class LambdaExpressionDemo3 {
public static void main(String args[]) {
	min s = (x,y)->{
		int min = x>y?y:x;
		return min;
		};
	int t=s.calcSum(12,10);
	System.out.println(t);
}
}
