enum Color{
	Red,Green,Blue,Yellow;
}
interface StateChangeListener{
	public void onStateChange(); //no body so write anonymus class
} 
class Owner implements StateChangeListener{
	void add(Color c) {
		c.onStateChange();
		System.out.println("color");
	}
class TestSample extends Owner{
	void colorChanege(Color c) {
		add(obj);
	}
}

}
class SampleState{
	public static void ChangeColor(Color c) {
		System.out.println("Change color");
	}
}
//class TestSample{
//	void displayColor(){
//		System.out.println("displaycolor");
//	}
//}
public class AnonymusClassDemo2 {
public static void main(String args[]) {
	SampleState obj1 = new SampleState();
	TestSample obj2 = new TestSample();
	obj1.ChangeColor(Color.Red);
	obj2.displayColor();
}
}