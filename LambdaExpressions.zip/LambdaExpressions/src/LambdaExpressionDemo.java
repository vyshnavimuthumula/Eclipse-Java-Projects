@FunctionalInterface
interface Sum{
		int calcSum(int x);
}
public class LambdaExpressionDemo {
public static void main(String args[]) {
	Sum s=(v)->v+10;
	int x=s.calcSum(23);
	System.out.println(x);
}
}
