@FunctionalInterface
interface voiddemo{
	Object disp();
}
public class LambdaExpressionvoidDemo {
public static void main(String args[]) {
	voiddemo s= ()->{
		String s2 = "hi";
		return s2;
	};
	Object s2 = s.disp();
	System.out.println(s2);
}
}
