@FunctionalInterface
interface Bounceable{
	public void bounce();
}
class Ball implements Bounceable{
	public void Bounce() {
		System.out.println("Ball bouncing");
	}

	@Override
	public void bounce() {
		// TODO Auto-generated method stub
		
	}
}
public class AnonymusInnerClass {
	public static void main(String args[]) {
		Ball b = new Ball();
		b.bounce();
		Bounceable b1 = new Bounceable() {
			public void bounce() {
				System.out.println("Anonymus Bouncing");
			}
		};
		b1.bounce();
		// Lambda Expression
		Bounceable b2=()->{
			System.out.println("Lambda expression bouncing");
		};
		b2.bounce();
		}
	}
