@FunctionalInterface
interface StringDemo{
	String display();
}
public class LambdaExpressionString {
public static void main(String args[]) {
	StringDemo s = ()->"hi";
	String p=s.display();
	System.out.println(p);
}
}
