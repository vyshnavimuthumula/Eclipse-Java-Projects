package com.cg.bean;

import java.util.ArrayList;
import java.util.List;

public class Bank {
	
	private String name;
	private String adharNum;
	private String phoneNum;
	private int pin;
	private int balance;
	private int accnum;
	private List<String> transList= new ArrayList<String>();
	public List<String> getTransList() {
		return transList;
	}
	public void setTransList(List<String> transList) {
		this.transList = transList;
	}
	public static int getAccountnum() {
		return accountnum;
	}
	public static void setAccountnum(int accountnum) {
		Bank.accountnum = accountnum;
	}
	public void setAccnum(int accnum) {
		this.accnum = accnum;
	}
	static int accountnum=1000;

	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAdharNum() {
		return adharNum;
	}
	public void setAdharNum(String adharNum) {
		this.adharNum = adharNum;
	}
	public String getPhoneNum() {
		return phoneNum;
	}
	public void setPhoneNum(String phoneNum) {
		this.phoneNum = phoneNum;
	}
	public int getPin() {
		return pin;
	}
	public void setPin(int pin) {
		this.pin = pin;
	}
	public int getBalance() {
		return balance;
	}
	public void setBalance(int balance) {
		this.balance = balance;
	}
	
	public int getAccnum() {
		return accnum;
	}
	public void setAccnum() {
		this.accnum = ++accountnum;
	}
	@Override
	public String toString() {
		return "Bank [name=" + name + ", adharNum=" + adharNum + ", phoneNum=" + phoneNum + ", pin=" + pin
				+ ", balance=" + balance + ", accnum=" + accnum + "]";
	}
//	Validation valid =new Validation();
	
	
}
