package com.cg.emp.bean;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.Pattern;

@Entity
public class Employee {
	@Id
	private int id;
	@Pattern(regexp="[A-Z][A-Za-z\\s]{2,}",message="Name should start with capital letters and minimum length 2")
	private String name;
	private String gender;//@Size(min=4,max=6,message="Gender should be between 4 and 6 Characters")
	@Min(18)
	@Max(60)
	private int age;
	@Pattern(regexp="\\d{10}",message="Mobile Number should be 10 digits")
	private String mobile;
	private double salary;
	@Override
	public String toString() {
		return "Employee [id=" + id + ", name=" + name + ", gender=" + gender + ", age=" + age + ", mobile=" + mobile
				+ ", salary=" + salary + "]";
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public String getMobile() {
		return mobile;
	}
	public void setMobile(String mobile) {
		this.mobile = mobile;
	}
	public double getSalary() {
		return salary;
	}
	public void setSalary(double salary) {
		this.salary = salary;
	}

}
