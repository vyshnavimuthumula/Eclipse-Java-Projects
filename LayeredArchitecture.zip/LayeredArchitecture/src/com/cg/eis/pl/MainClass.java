package com.cg.eis.pl;
import java.io.IOException;
import java.util.Scanner;
public class MainClass {
public static void main(String[] args) throws IOException{    
    System.out.println("EMPLOYEE MEDICAL INSURANCE SCHEME\n");
    System.out.println("1. Enter the Employee Details");
    System.out.println("2. Display the Employee Details");
    System.out.println("3. Exit");
    System.out.println("Please enter your choice: ");    
    int ch;
    Scanner sc = new Scanner(System.in);
    ch = sc.nextInt();    
    switch(ch) {    
    case 1: 
    	UserInput ui = new UserInput();
        ui.readInput(); //call readInput() for read the data from the user
        break;            
    case 2: 
    	DisplayOutput displayOutput = new DisplayOutput();
        displayOutput.showOutput(null); //call showOutput() for Display all the details
        break;       
    case 3: 
    	System.exit(0);     //to terminate the program        
    
    default: 
    	System.out.println("Enter the correct input...");
        break;
    }
    sc.close();
    }
}
 







