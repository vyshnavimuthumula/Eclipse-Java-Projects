package lab8;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;

public class Ex4File {
			public static void main(String args[]) throws IOException {
				File file = new File("C:\\Users\\vymuthum\\Desktop\\game.txt");
				String fileType="undefined";
				if ((file.exists())) {
					System.out.println("File exists");
				    if(file.canWrite())
				    	System.out.println("File is writable");
				    if(file.canRead())
				    	System.out.println("File is readable");
				    fileType = Files.probeContentType(file.toPath());
				    System.out.println(file.length());
				    System.out.println(file.length());
				    System.out.println(fileType);
				}
				else
					System.out.println("File not found");
				
				
			  } 
		}


