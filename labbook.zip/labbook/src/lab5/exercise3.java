package lab5;

import java.util.Scanner;

public class exercise3 {
	public static void main(String args[]) {
		int n;
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter a number");
		n = sc.nextInt();
//		int i,c=1;
//		for(i=2;(i*i)<n;i++) {
//			if(n%i==0) {
//				c++;
//			}
//		}
//			if(c==2)
//				System.out.println("not a prime number ");
//			else 
//				System.out.println("prime number ");
		
		for(int i=1;i<=n;i++)
		{
			int c1=0;
			for(int j=1;j<=i;j++)
			{
				if(i%j==0)
					c1++;
			}
			if(c1<=2)
			{
				System.out.println(i);
			}
			
			}
		
	}
	
}

