package lab5;
import java.util.*;
public class exercise1 {
public static void main(String args[]) {
	String n;
	Scanner sc = new Scanner(System.in);
	n = sc.next();
	switch(n) {
	case "red":
		System.out.print("stop");
		break;
	case "yellow":
		System.out.print("ready");
		break;
	case "green":
		System.out.print("go");
		break;
	default :
		System.out.println("Enter valid color");
		sc.close();
		
	
	}
}
}
