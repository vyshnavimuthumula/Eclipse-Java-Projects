package lab5;
import java.util.*;
public class Ex4NameValidation {
public static void main(String[] args) {
	String str;
	Scanner sc = new Scanner(System.in);
	System.out.println("Enter your name");
	str = sc.nextLine();
	System.out.println(str);
	if(str.matches("[A-Z][a-z]*([ ][A-Z][a-z]*)*"))
		System.out.println("valid name");
	else
		System.out.println("Invalid name");
	sc.close();
	//*
}
}
