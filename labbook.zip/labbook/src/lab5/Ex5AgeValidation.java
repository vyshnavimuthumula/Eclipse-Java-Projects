package lab5;
import java.util.*;

@SuppressWarnings("serial")
class Ex5AgeValidation extends RuntimeException{			
	public String toString() {
		return "Exception found because of invalid age";
	} 
	public static void main(String args[]) {
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter age");
		int age = sc.nextInt();
		sc.close();
		try {
			if(age<=15)
				throw new ThrowException();
			else 
				System.out.println("Valid age");
		}
		catch(Exception e) {
			System.out.println("Exception15found because of invalid age");	
		}
	}
	}


