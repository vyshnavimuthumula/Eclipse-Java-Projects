package lab3;
import java.util.*;
public class exercise2 {
    public static void main(String args[])
    {        
        StringConvertion();
    } 
    private static void StringConvertion() {
        int n,i;
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter size of the string");
        n=sc.nextInt();
        String str[] = new String[n];  
        System.out.println("Enter string");
        for(i=0;i<n;i++)
            str[i]=sc.next();
        sc.close();        
        if(str.length%2==0)
        {
            for(i=0;i<str.length/2;i++)
                str[i]=str[i].toUpperCase();
            for(i=str.length/2;i<str.length;i++)
                str[i]=str[i].toLowerCase();
        }
        else
        {
            for(i=0;i<str.length/2+1;i++)
                str[i]=str[i].toUpperCase();
            for(i=str.length/2+1;i<str.length;i++)
                str[i]=str[i].toLowerCase();
        }        
        Arrays.sort(str);
        for(String s:str)
            System.out.print(s +" ");        
    } 
}