package lab3;
import java.util.Scanner;
public class exercise1 {
	public static void main(String args[]) {
		SecondSmallest();
	}
	public static void SecondSmallest() {
		int n;
		Scanner sc = new Scanner(System.in);
		n = sc.nextInt();
		System.out.println("Enter array elements");
		int a[] = new int[n];
		int i;
		for(i=0;i<n;i++) {
			a[i]=sc.nextInt();
			
		}
		int dummy;
		for(i=0;i<n;i++) {
			for(int j=i+1;j<n;j++) {
			if(a[i]>a[j]) {
				dummy=a[i];
				a[i]=a[j];
			    a[j]=dummy;
			}
			}
		}
		sc.close();
		System.out.println("Secondsmallest is " + a[1]);
		//System.out.println("List of array is" + a[i]);
	}
}


