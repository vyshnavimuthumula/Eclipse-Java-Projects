package lab13;

import java.util.Scanner;

@FunctionalInterface
interface Factorial{
	public int factcalc(int x);
} 
public class Exercise5 {
	public static void main(String args[]) {
		Factorial fact = (int n)->{
			int f=1;
			for(int i=1;i<=n;i++)
				f = f*i;
			return f;
		};
		System.out.println("Enter your number");
		Scanner sc = new Scanner(System.in);
		int x = sc.nextInt();
		System.out.println(fact.factcalc(x));
		sc.close();
	}
}
