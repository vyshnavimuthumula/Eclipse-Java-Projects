package lab1;

import java.util.Scanner;

public class exercise2 {
	public static void main(String args[]) {
		calculateDifference();
	}
	public static void calculateDifference() {
		int n;
		Scanner sc = new Scanner(System.in);
		n = sc.nextInt();
		int i,sum1=0,sum2=0,diff=0;
		for(i=1;i<=n;i++) {
			sum1 = sum1+(i*i);
			sum2 = sum2+i;
		}
		diff = sum1 - (sum2 * sum2);			
		
		sc.close();
		System.out.println("Difference is " + diff);
	}
}
