package lab1;
import java.util.*;
public class exercise3 {
	public static void main(String args[]) {
		checkNumber();
	}
	public static void checkNumber(){
		int n;
		Scanner sc = new Scanner(System.in);
		n = sc.nextInt();
		int temp=n;
		int r1,r2;
		boolean check = false;
		while(n>0) {
			r1 = n%10;
			n = n/10;
			r2 = n%10;
			if(r1<r2) 
				check=true;		
			}
		if(check == false)
			System.out.println(temp + " is an increasing number");
		else
			System.out.println(temp + " is not an increasing number");
	}
}