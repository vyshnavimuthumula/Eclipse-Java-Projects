package lab1;

import java.util.Scanner;
//import java.lang.Math;
public class exercise4 {
	public static void main(String args[]) {
		checkNumber();
	}
	public static void checkNumber() {
		int n;
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the number");
		n = sc.nextInt();
		if(n>0)
			if(((n&(n-1))==0))
				System.out.println(n + " is power of 2");
			else 
				System.out.println(n + " is not power of 2");
		else 
			System.out.println(n + " is not power of 2");
		sc.close();
	}
}
