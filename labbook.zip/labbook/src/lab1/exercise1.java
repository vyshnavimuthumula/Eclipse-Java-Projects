package lab1;
import java.util.*;
public class exercise1 {
	public static void main(String args[]) {
		calculateSum();
		
	}
	private static void calculateSum() {
		// TODO Auto-generated method stub
		
	}
	public static void checkSum() {
		int n;
		Scanner sc = new Scanner(System.in);
		n = sc.nextInt();
		int sum=0;
		for(int i=n;i>0;i--) {
			if((i%3==0)||(i%5==0))
					sum=sum+i;
		}
		sc.close();
		System.out.println("Sum of digits which is divisible by 3 or 5 "+ sum);
	}
}
