package lab2;

public abstract class Item {
	private int IdNum;
	private String Title;
	private int NumOfCopies;
	Item(int IdNum, String Title, int NumOfCopies){
		this.IdNum = IdNum;
		this.Title = Title;
		this.NumOfCopies = NumOfCopies;
	}
	public void setIdNum(int IdNum)
	{
		this.IdNum = IdNum;
	}
	public int getIdNum()
	{
		return IdNum;
	}
	public void settitle(String Title)
	{
		this.Title = Title;
	}
	public String getTitle()
	{
		return Title;
	}
	public void setNumOfCopies(int NumOfCopies)
	{
		this.NumOfCopies = NumOfCopies;
	}
	public int getNumOfCopies()
	{
		return NumOfCopies;
	}
}


abstract class WrittenItem extends Item{

	private String author;
	WrittenItem(int IdNum, String Title, int NumOfCopies, String author) {
		super(IdNum, Title, NumOfCopies);
		this.setAuthor(author);
		// TODO Auto-generated constructor stub
	}
	public String getAuthor() {
		return author;
	}
	public void setAuthor(String author) {
		this.author = author;
	}
	
}
abstract class Book extends WrittenItem{

	Book(int IdNum, String Title, int NumOfCopies, String author) {
		super(IdNum, Title, NumOfCopies, author);
		// TODO Auto-generated constructor stub
	}
	
}
abstract class JournalPaper extends WrittenItem{
	private int year;
	JournalPaper(int IdNum, String Title, int NumOfCopies, String author, int year) {
		super(IdNum, Title, NumOfCopies, author);
		this.setYear(year);
		// TODO Auto-generated constructor stub
	}
	public int getYear() {
		return year;
	}
	public void setYear(int year) {
		this.year = year;
	}
	
}
abstract class MediaItem extends Item{
	private int runtime;
	MediaItem(int IdNum, String Title, int NumOfCopies, int runtime) {
		super(IdNum, Title, NumOfCopies);
		this.setRuntime(runtime);
		// TODO Auto-generated constructor stub
	}
	public int getRuntime() {
		return runtime;
	}
	public void setRuntime(int runtime) {
		this.runtime = runtime;
	}
	
}
abstract class Video extends MediaItem{
	private String Genre;
	Video(int IdNum, String Title, int NumOfCopies, int runtime, String Director, String Genre, int year) {
		super(IdNum, Title, NumOfCopies, runtime);
		this.setGenre(Genre);
	}
	public String getGenre() {
		return Genre;
	}
	public void setGenre(String genre) {
		Genre = genre;
	}
	
}
abstract class CD extends MediaItem{
	private String Artist,genre;
	CD(int IdNum, String Title, int NumOfCopies, int runtime, String Artist, String genre) {
		super(IdNum, Title, NumOfCopies, runtime);
		this.setArtist(Artist);
		this.setGenre(genre);
		// TODO Auto-generated constructor stub
	}
	public String getArtist() {
		return Artist;
	}
	public void setArtist(String artist) {
		Artist = artist;
	}
	public String getGenre() {
		return genre;
	}
	public void setGenre(String genre) {
		this.genre = genre;
	}
	
}
