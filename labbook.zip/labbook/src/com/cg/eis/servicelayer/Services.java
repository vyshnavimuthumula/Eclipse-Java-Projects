package com.cg.eis.servicelayer;

import java.io.IOException;

import com.cg.eis.bean1.Employee;
import com.cg.eis.dao.DataStorage;

public class Services  {
	private String service;
	public String getService() {
		return service;
	}
	public void setService(String service) {
		this.service = service;
	}
	public void serviceprovide(Employee employee) {
		// TODO Auto-generated method stub
		Services s = new Services();
		if(employee.getScheme()=="Scheme C")
			s.setService("Free food");
		else if(employee.getScheme()=="Scheme B")
			s.setService("Free Shopping");
		else if(employee.getScheme()=="Scheme A")
			s.setService("Free wifi");
		else
			s.setService("No benefits");
		System.out.println(employee.getScheme());
		DataStorage ds = new DataStorage();
		ds.storeData(employee,s);
	}
	

}
