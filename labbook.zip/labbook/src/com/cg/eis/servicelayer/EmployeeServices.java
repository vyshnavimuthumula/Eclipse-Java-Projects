package com.cg.eis.servicelayer;

public interface EmployeeServices {

}
