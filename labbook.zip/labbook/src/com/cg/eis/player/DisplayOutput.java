package com.cg.eis.player;

import java.util.ArrayList;

public class DisplayOutput {

	public void showOutput(ArrayList<String> arraylist) {
		// TODO Auto-generated method stub
		for(String str :arraylist)
			System.out.println(str);
	}

}
