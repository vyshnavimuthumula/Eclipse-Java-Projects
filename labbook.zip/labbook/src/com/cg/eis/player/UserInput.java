package com.cg.eis.player;

import java.util.Scanner;

import com.cg.eis.bean1.Employee;
import com.cg.eis.servicelayer.Services;

public class UserInput {
	public void empDetails() {
		int empId,salary,interest;
		String empName,empDesignation;
		Employee employee = new Employee();
		Scanner sc = new Scanner(System.in);
		Scanner sc1 = new Scanner(System.in);
		System.out.println("Enter Employee ID : ");
		empId = sc.nextInt();
		employee.setEmpId(empId);
		System.out.println("Enter Employee name : ");
		empName = sc1.nextLine();
		employee.setEmpName(empName);
		System.out.println("Enter salary");
		salary = sc.nextInt();
		employee.setSalary(salary);
		System.out.println("Enter interest ");
		interest = sc.nextInt();
		employee.setInterest(interest);
		System.out.println("Enter designation");
		empDesignation = sc1.nextLine();
		employee.setEmpDesignation(empDesignation);
		if((salary>5000 && salary<20000) &&(empDesignation=="System Associate"))
			employee.setScheme("Scheme C");
		else if((salary>=20000 && salary<40000) &&(empDesignation=="Programmer"))
			employee.setScheme("Scheme B");
		else if((salary>40000 ) &&(empDesignation=="Manager"))
			employee.setScheme("Scheme A");
		else if((salary<5000) &&(empDesignation=="Clerk"))
			employee.setScheme("Scheme D");
		else 
			employee.setScheme("No Scheme");
		sc.close();
		System.out.println(employee.getScheme());
		Services empServices = new Services();
		empServices.serviceprovide(employee);
		
	}
}
