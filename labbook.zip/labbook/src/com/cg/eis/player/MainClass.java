package com.cg.eis.player;

import java.util.Scanner;

public class MainClass {
public static void main(String args[]) {
	System.out.println("Employee Medical Insurance Scheme");
	System.out.println("1. Enter Employee details");
	System.out.println("2. Display Employee details");
	System.out.println("3. Exit ");
	int n;
	Scanner sc = new Scanner(System.in);
	n = sc.nextInt();
	switch(n) {
	case 1:
		UserInput ui = new UserInput();
		ui.empDetails();
		break;
	case 2:
		DisplayOutput displayop = new DisplayOutput();
		displayop.showOutput(null);
		break;
	case 3 :
		System.exit(0);
	default :
		System.out.println("Please enter valid key");
	}
		
}
}
