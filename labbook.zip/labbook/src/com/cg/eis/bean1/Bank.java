package com.cg.eis.bean1;

public class Bank {
private double interest;
public Bank (double interest) {
	super();
	this.interest=interest;
}
public double getInterest() {
	return interest;
}
public void setInterest(double interest) {
	this.interest=interest;
}
}
