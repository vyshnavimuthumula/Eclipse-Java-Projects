package com.cg.eis.bean1;

public class Employee {
	private int empId;
	private String empName,empDesignation;
	private int salary;
	private int interest;
	private String Scheme;
	public String getScheme() {
		return Scheme;
	}
	public void setScheme(String scheme) {
		Scheme = scheme;
	}
	public Employee() {
		
	}
	public Employee(int empId,String empName,int interest,int salary,String scheme) {
		super();
		this.empId = empId;
		this.empName = empName;
		this.interest = interest;
		this.salary = salary;
		this.Scheme = scheme;
	}
	public int getEmpId() {
		return empId;
	}
	public void setEmpId(int empId) {
		this.empId=empId;
	}
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName=empName;
	}
	public int getInterest() {
		return interest;
	}
	public void setInterest(int interest) {
		this.interest=interest;
	}
	@Override
	public String toString() {
		return "Employee [empId=" + empId + ", empName=" + empName + ", salary=" + salary + ", interest=" + interest
				+ "]";
	}
	public int getSalary() {
		return salary;
	}
	public void setSalary(int salary) {
		this.salary=salary;
	}
	public String getEmpDesignation() {
		return empDesignation;
	}
	public void setEmpDesignation(String empDesignation) {
		this.empDesignation = empDesignation;
	}
}
