package com.cg.eis.dao;

import java.util.ArrayList;

import com.cg.eis.bean1.Employee;
import com.cg.eis.player.DisplayOutput;
import com.cg.eis.servicelayer.Services;

public class DataStorage {

	public void storeData(Employee employee, Services s) {
		// TODO Auto-generated method stub
		ArrayList<String> arrayList = new ArrayList<String>();
		arrayList.add("Employee Id: " + employee.getEmpId());
		arrayList.add("Employee Name: " + employee.getEmpName());
		arrayList.add("Salary : " +employee.getSalary());
		arrayList.add("Insurance Scheme " + employee.getScheme());
		arrayList.add("Services provided " + s.getService());
		DisplayOutput displayOutput = new DisplayOutput();
		displayOutput.showOutput(arrayList);
	}



}
