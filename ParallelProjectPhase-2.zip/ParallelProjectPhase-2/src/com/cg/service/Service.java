package com.cg.service;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.cd.dao.DataStorage;
import com.cg.bean.Bank;
import com.cg.bean.Transaction;


public class Service {	

	
	Scanner sc = new Scanner(System.in);
	
	DataStorage database=new DataStorage();
	
	DataStorage transactiondata=new DataStorage();
	
     public void accountDetails() {
     	Transaction transaction=new Transaction();
     	Bank bank = new Bank();
		System.out.print("Enter your name:");
		bank.setName(sc.next());
		System.out.print("Enter Adhaar details:");
		bank.setAdharNum(sc.next());
		System.out.print("Enter your Mobile Number:");
		bank.setPhoneNum(sc.next());
		bank.setAccnum();
		System.out.println("set the pin to the account");
		bank.setPin(sc.nextInt());
		System.out.println("Enter the amount to be deposited");
		bank.setBalance(sc.nextInt());
		System.out.println("Account created successfully");
		System.out.println("Your Account Number is: "+bank.getAccnum());
		database.storeCustomerDetails(bank);
		transaction.setAccountnum(bank.getAccnum());
		transaction.setCredit(bank.getBalance());
		transaction.setDebit(0);
		transaction.setTotalbal(bank.getBalance());
		transactiondata.storeTransactionDetails(transaction);
		
		bank.getTransList().add("credited amount "+bank.getBalance());
		System.out.println(bank.getTransList());
	}
     	
	public int showBalance() {
		
		int accountno;
		int pin;
		System.out.println("Enter account number");
		accountno = sc.nextInt();
		System.out.println("Enter your pin");
		pin=sc.nextInt();
		List<Bank> custList=database.getCustomerDetails();
		for(Bank cust:custList) {
			if(cust.getAccnum()==accountno && cust.getPin()==pin)
				return cust.getBalance();
		}
		return 0;			
					
	}
	
	
	
	public int dataDeposit() {
		Transaction transaction1=new Transaction();
		Bank bank = new Bank();
		int accountno;
		System.out.println("Enter the account no");
		accountno = sc.nextInt();
		List<Bank> custList=database.getCustomerDetails();
		for(Bank cust:custList) {
			if(cust.getAccnum()==accountno){
				System.out.println("Enter the amount to be depoist: ");
				int amount = sc.nextInt();
				cust.setBalance(cust.getBalance()+amount);
				System.out.println("Amount successfully debited");
				transaction1.setAccountnum(cust.getAccnum());
				transaction1.setCredit(cust.getBalance());
				transaction1.setDebit(0);
				transaction1.setTotalbal(cust.getBalance());
				transactiondata.storeTransactionDetails(transaction1);
				//bank.getTransList().add("deposited money "+ amount);
				return cust.getBalance();	
				
			}
		}
		return 0;
	}

	public int withDrawal() {
		Transaction transaction2=new Transaction();
		Bank bank = new Bank();
		int accountno;
		System.out.println("Enter the account no");
		accountno = sc.nextInt();
		List<Bank> custList=database.getCustomerDetails();
		for(Bank cust:custList) {
			if(cust.getAccnum()==accountno){
				System.out.println("Enter the amount to be withdrawal: ");
				int amount = sc.nextInt();
				if(cust.getBalance()>amount) {
					cust.setBalance(cust.getBalance()-amount);
					System.out.println("Amount successfully credited");
					transaction2.setAccountnum(cust.getAccnum());
					transaction2.setCredit(0);
					transaction2.setDebit(cust.getBalance());
					transaction2.setTotalbal(cust.getBalance());
					transactiondata.storeTransactionDetails(transaction2);
					//bank.getTransList().add("deposited money "+ amount);
					return cust.getBalance();	
				}
				else
					System.out.println("Invalid amount");
			}
		}
		return 0;
		
	}
	public void fundTrans() {
		Transaction transaction3=new Transaction();
		List<Bank> customerList=database.getCustomerDetails();
		int senderacc,receiveracc,transferamt;
		
		System.out.println("Enter receiver account number");
		receiveracc = sc.nextInt();
		System.out.println("Enter senders account number");
		senderacc= sc.nextInt();
		System.out.println("Enter amount to be transfer");
		transferamt=sc.nextInt();
		for(Bank acc1:customerList) {
			for(Bank acc2:customerList) {
				if(senderacc==acc1.getAccnum() && receiveracc==acc2.getAccnum()) {				
						acc1.setBalance(acc1.getBalance()-transferamt);
						acc2.setBalance(acc2.getBalance()+transferamt);
						transaction3.setAccountnum(acc1.getAccnum());
						transaction3.setCredit(transferamt);
						transaction3.setDebit(0);
						transaction3.setTotalbal(acc1.getBalance());
						transaction3.setAccountnum(acc2.getAccnum());
						transaction3.setDebit(transferamt);
						transaction3.setCredit(0);
						transaction3.setTotalbal(acc2.getBalance());
						transactiondata.storeTransactionDetails(transaction3);
						//transactiondata.add(transaction3);
				}
			}
		}
		
		
	}

	public void printTransaction() {
		 List<Transaction> trasactionlist=new ArrayList<Transaction>();
		//List<String> transList= new ArrayList<String>();
		for(Transaction list:trasactionlist) {
			System.out.println(list);
		}
	}

}
