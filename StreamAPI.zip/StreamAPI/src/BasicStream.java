import java.util.Arrays;
import java.util.List;
import java.util.stream.Stream;
public class BasicStream {
public static void main(String[] args) {
	Stream <String> Stream = java.util.stream.Stream.of("I","g","a");
			Stream.forEach(location)->System.out.println(location);
	List<String>Locations=Arrays.asList(new String[]{"pune","mumbai"});
	Stream=Locations.stream();
	Stream.forEach(System.out::println);
}
}
