import java.util.*;
import java.util.function.Predicate;
import java.util.stream.Collectors;
import java.util.stream.Stream;
public class FilterCollectionDemo {
public static void main(String args[]) {
	List<Integer>numberList = new ArrayList<Integer>();
	numberList.add(10);
	numberList.add(11);
	numberList.add(12);
	numberList.add(13);
	numberList.add(14);
	Predicate<Integer> p = new Predicate<Integer>() {
		public boolean test(Integer i) {
			boolean val = false;
			if(i%2==0)
				val=true;
			return val;
		}
	};
	Stream<Integer>numberStream = numberList.stream();
	Stream<Integer>filterStream = numberStream.filter(p);
	filterStream.forEach(System.out::println);
	System.out.println();
	List evenlist = numberList.stream().filter(i->i%2==0).collect(Collectors.toList());
	System.out.println(evenlist);
}
}
