package com.capg.assignment1;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class Main {
	public static void main(String args[]) {
		EntityManagerFactory factory = Persistence.createEntityManagerFactory("JPA-PU");
		EntityManager entitymanager = factory.createEntityManager();
		
		AuthorDetails auth = new AuthorDetails();
		auth.setName("Singh");
		
		BookDetails book = new BookDetails();
		book.setISBN(152);
		book.setTitle("Surgery Essence");
		book.setPrice(200);
		
		BookDetails book2 = new BookDetails();
		book2.setISBN(123);
		book2.setTitle("Java");
		book2.setPrice(230);
		
		auth.getBook().add(book);
		auth.getBook().add(book2);
		
		entitymanager.getTransaction().begin();
		entitymanager.persist(auth);
	
//		entitymanager.persist(book);
		entitymanager.getTransaction().commit();
	}
	
}
