package com.capg.assignment2;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity
public class Book2 {
	@Id
	@GeneratedValue()	
	private int ISBN;
	private int price;
	private String title;
	public int getISBN() {
		return ISBN;
	}
	public void setISBN(int iSBN) {
		ISBN = iSBN;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	@Override
	public String toString() {
		return "Book2 [ISBN=" + ISBN + ", price=" + price + ", title=" + title + "]";
	}
	public Object getAuthor() {
		// TODO Auto-generated method stub
		return null;
	}

	
}
