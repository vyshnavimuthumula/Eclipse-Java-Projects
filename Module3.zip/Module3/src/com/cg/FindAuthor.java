package com.cg;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class FindAuthor {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.print("welcome");
		EntityManagerFactory factory=Persistence.createEntityManagerFactory("JPA-PU");
		EntityManager em = factory.createEntityManager();
		em.getTransaction().begin();
		Author auth = new Author();
		auth.setId(101);
		auth.setFirstName("vyshnavi");
		auth.setMiddleName("reddy");
		auth.setLastname("muthumula");
		auth.setPhoneNo(12345654);
		
		
		em.persist(auth);
		em.getTransaction().commit();
	}

}
