package GameException;

public class Description {
	void GameDescription(){
		System.out.println("The country or city names are jumbled so find the correct city or country name");
	}
}
