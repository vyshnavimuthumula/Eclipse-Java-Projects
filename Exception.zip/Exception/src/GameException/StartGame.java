package GameException;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.*;
public class StartGame extends Game {
	void Start() throws FileNotFoundException {
	int t;
	System.out.println("Please select your catagory to play the game");
	Scanner sc = new Scanner(System.in);
	t = sc.nextInt();	
	switch(t) {
		case 1:
			System.out.println("CITY NAME");
			//read the file and give one jumbled city name
			BufferedReader reader = new BufferedReader(new FileReader("C:\\Users\\vymuthum\\Desktop\\game.txt"));
			String uin;
			uin = sc.next();
			break;
		case 2:
			System.out.println("COUNTRY NAME");
			break;
		default :
			System.out.println("Enter valid catagory");
	}
	}
}
