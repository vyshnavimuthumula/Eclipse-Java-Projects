package GameException;
import java.io.FileNotFoundException;
import java.util.*;
public class Game {
	public static void main(String[] args) throws FileNotFoundException {
	int n;
	Scanner sc = new Scanner(System.in);
	System.out.println("Game");
	System.out.println("Menu \n1.Start \n2.Description \n3.Exit ");
	String name;
	System.out.println("Enter your name");
	name = sc.next();
	System.out.println("Enter a number");
	n = sc.nextInt();
	switch(n){
		case 1 :
			System.out.println("Start the game");
			StartGame obj1 = new StartGame();
		try {
			obj1.Start();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
			break;
		case 2 :
			System.out.println("Game Description");
			Description obj2 = new Description();
			obj2.GameDescription();
			break;
		case 3:
			System.exit(0);
		default:
			System.out.println("Enter valid option");
			break;
				
			
	}
	
}
}
