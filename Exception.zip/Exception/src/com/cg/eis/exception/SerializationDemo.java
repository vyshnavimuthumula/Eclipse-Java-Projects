package com.cg.eis.exception;
import 
public class SerializationDemo implements Serializable {
	String s1,s2;
	public SerializationDemo(String s1, String s2) {
		this.s1 = s1;
		this.s2 = s2;
	}
	
	public String toString () {
		return s1 + " " + s2;
	}

}
