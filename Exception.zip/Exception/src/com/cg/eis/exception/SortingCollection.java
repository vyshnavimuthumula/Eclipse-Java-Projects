package com.cg.eis.exception;

import java.util.*;

public class SortingCollection {
	public static void main(String args[]) {
		int a[]= {23,67,7,89,50};
		Arrays.sort(a);
		for(int i:a)
			System.out.println(i);
		LinkedList<String> lObj= new LinkedList<String>();
		lObj.add("jake");
		lObj.add("Mike");
		lObj.add("cat");
		System.out.println(lObj);
		System.out.println("*****");
		Collections.sort(lObj);
		System.out.println(lObj);
		
		
		}

}
