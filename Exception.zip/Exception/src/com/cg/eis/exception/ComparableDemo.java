package com.cg.eis.exception;

public class ComparableDemo {

}
