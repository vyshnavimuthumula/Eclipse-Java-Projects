package com.cg.eis.exception;
import java.util.*;
public class HashMapDemo {
	public static void main(String args[]) {
	
		HashMap<Integer,String> hm = new HashMap<Integer,String>();
		hm.put(1,"h");
		hm.put(2,"l");
		System.out.println(hm);

}
}