package com.cg.eis.exception;

import java.util.Scanner;

public class GenericCalculation {
	public static < E > void addition( E x,E y) {
		System.out.println(x + " " + y);
	}
	
public static void main(String args[]) {
	Scanner sc = new Scanner(System.in);
	int x,y;
	System.out.println("Enter two numbers");
	x = sc.nextInt();
	y = sc.nextInt();
	addition(x,y);
	String s1,s2;
	System.out.println("Enter strings");
	s1 = sc.next();
	s2 = sc.next();
	
	
	addition(s1,s2);
	sc.close();
	//z = x+y;
	//System.out.println("Addition of two numbers " + z);
}
}