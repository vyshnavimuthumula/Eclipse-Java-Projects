package com.cg.eis.exception;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class BufferedReaderDemo2 {
	public static void main(String args[]) throws IOException
	{
		BufferedReader reader = new BufferedReader(new FileReader("C:\\Users\\vymuthum\\Desktop\\game.txt"));
		String text = null;
		while((text=reader.readLine())!=null) {
				System.out.println(text);
		}
	}
}
