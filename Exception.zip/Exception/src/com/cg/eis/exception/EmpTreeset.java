package com.cg.eis.exception;
import java.util.*;
public class EmpTreeset implements Comparable<EmpTreeset>{
		int empid;
		String name;
		EmpTreeset(int empid, String name) {
			super();
			this.empid=empid;
			this.name = name;
		}
		public String toString(){
			return empid + " " + name;
		}
		public static void main(String args[]) {
		EmpTreeset emp1 = new EmpTreeset(1,"jake");
		EmpTreeset emp2 = new EmpTreeset(2,"kate");
		TreeSet <EmpTreeset> ts = new TreeSet<EmpTreeset>();
		ts.add(emp1);
		ts.add(emp2);
		//System.out.println(ts);
		
		for(EmpTreeset e:ts) {
			System.out.println(e);
		}
		
		
	}
		@Override
		public int compareTo(EmpTreeset obj) {
			if(this.empid==obj.empid)
			  return 0;
			else 
				return this.empid>obj.empid?1:-1;
			// TODO Auto-generated method stub
		}
}
