package com.cg.eis.exception;
import java.util.*;
//import java.util.TreeSet;
public class TreeSetDemo {
	public static void main(String args[]) {
		TreeSet<String> ts = new TreeSet<String> ();
		ts.add("1");
		ts.add("2");
		ts.add("6");
		ts.add("0");
		ts.add("5");
		ts.add("hi");
		System.out.println(ts);
	}
}
