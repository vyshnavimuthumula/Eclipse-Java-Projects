package com.cg.eis.exception;
import java.util.*;

public class HashSetDemo {
	public static void main(String args[]) {
		HashSet<Comparable> hs=new HashSet<Comparable>();
		//Integer ii=4;
		//hs.add(ii);
		
		hs.add(1);
		hs.add(2.3);
		hs.add("hi");
		System.out.println(hs);
		Iterator<Comparable> i= hs.iterator();
		while(i.hasNext()) {
			System.out.println(i.next());
		}
		LinkedHashSet<Comparable> lhs = new LinkedHashSet<Comparable>();
		lhs.add(2);
		lhs.add(1);
		lhs.add("hi");
		System.out.println(lhs);
	
	}
}
