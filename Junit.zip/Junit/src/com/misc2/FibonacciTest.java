package com.misc2;

import static org.junit.Assert.assertEquals;

import java.util.Arrays;
import java.util.Collections;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;
import org.junit.runners.Parameterized.Parameters;

@RunWith(Parameterized.class)
public class FibonacciTest {
	static {
		System.out.println("sib");
	}
	@Parameters
	public static Collections data(){
		return (Collections) Arrays.asList(new Object[][]{
			{0,0},{1,1},{2,1},{3,2},{4,3},{5,5},{6,8}});
		}
private int fInput;
private int fExpected;
public FibonacciTest(int input,int expected) {
	this.fInput = input;
	this.fExpected = expected;
}
@Test
public void test() {
	System.out.println("test");
	assertEquals(fExpected, Fibonacci.compute(fInput));
}
@BeforeClass
public static void initBeforeClass() {
	System.out.println("initBeforeClass");
} 
@AfterClass
public static void cleanAfterClass() {
	System.out.println("cleanAfterClass");
}
@Before
public void init1() {
	System.out.println("@Before-init1()");
}
@After
public void clean1() {
	System.out.println("@clean1");
}
}
