package com.misc2;

public class Fibonacci {

	public static Object compute(int fInput) {
		// TODO Auto-generated method stub
		
		return null;
	}

}
