package com.misc;

import junit.framework.TestCase;

//import junit.framework.TestCase;
public class ArithmethicTest2 extends TestCase{
	Arithmethic1 a1=null;
	@Override
	public void setUp() throws Exception{
		super.setUp();
		a1=new Arithmethic1();
	}
	@Override
	public void tearDown() throws Exception{
		super.setUp();
		a1=null;
	}
	public void testSum2() {
		
		int x=a1.mul(10,30);
		assertEquals(300,x);
		int y=a1.mul(10,30);
		assertEquals(300,y);
		int z=a1.mul(10,20);
		assertEquals(200,z);
	}
	public void testSum3() {
		int x=a1.sum(10,30,40);
		assertEquals(80,x);
		int y=a1.sum(10,30,10);
		assertEquals(50,y);
		int z=a1.sum(10,30,100);
		assertEquals(140,z);
	}
	public void testSub() {
		int x=a1.div(100,20);
		assertEquals(5,x);
		int y=a1.div(10,2);
		assertEquals(5,y);
		int z=a1.div(100,10);
		assertEquals(10,z);
	}
}