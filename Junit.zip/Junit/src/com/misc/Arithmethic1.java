package com.misc;

public class Arithmethic1 {
	public int a=1,b=9,c=5;
	public int sum(int a,int b) {
		return (a+b);
	}
	public int sum(int a, int b, int c) {
		return (a+b+c);
	}
	public int sub(int a,int b) {
		return (a-b);
	}
	public int mul(int a, int b) {
		return (a * b);
	}
	public int div(int a, int b) {
		return (a/b);
	}
}
