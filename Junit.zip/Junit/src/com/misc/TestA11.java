package com.misc;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;

@RunWith(Suite.class)
@Suite.SuiteClasses({ArithmethicTest1.class,ArithmethicTest2.class})
public class TestA11 {
static {System.out.println("jgh");}

}
