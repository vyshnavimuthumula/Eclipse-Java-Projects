package com.misc;

import junit.framework.TestCase;

//import junit.framework.TestCase;
public class ArithmethicTest1 extends TestCase{
	Arithmethic1 a1=null;
	@Override
	public void setUp() throws Exception{
		super.setUp();
		a1=new Arithmethic1();
	}
	@Override
	public void tearDown() throws Exception{
		super.setUp();
		a1=null;
	}
	public void testSum2() {
		
		int x=a1.sum(10,30);
		assertEquals(40,x);
		int y=a1.sum(10,30);
		assertEquals(40,y);
		int z=a1.sum(10,30);
		assertEquals(40,z);
	}
	public void testSum3() {
		int x=a1.sum(10,30,40);
		assertEquals(80,x);
		int y=a1.sum(10,30,10);
		assertEquals(50,y);
		int z=a1.sum(10,30,100);
		assertEquals(140,z);
	}
	public void testSub() {
		int x=a1.sub(100,30);
		assertEquals(70,x);
		int y=a1.sub(10,3);
		assertEquals(7,y);
		int z=a1.sub(100,40);
		assertEquals(60,z);
	}
}