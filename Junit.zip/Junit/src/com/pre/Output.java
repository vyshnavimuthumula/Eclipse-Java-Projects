package com.pre;

import java.util.ArrayList;



public class Output {

 

    public void outputDisplay(ArrayList<String> a) {
        System.out.println(a);
        
    }

 

}