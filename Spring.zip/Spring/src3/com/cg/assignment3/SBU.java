package com.cg.assignment3;

import java.util.ArrayList;
import java.util.List;

public class SBU {
	private String sbuId;
	private String sbuName;
	private String sbuHead;
	
	List<Employee> emplist = new ArrayList<>();
	
	public String getSbuId() {
		return sbuId;
	}
	public void setSbuId(String sbuId) {
		this.sbuId = sbuId;
	}
	@Override
	public String toString() {
		return "sbuId=" + sbuId + ", sbuName=" + sbuName + ", sbuHead=" + sbuHead + " \nEmployee details:-------------\n" + emplist ;
	}
	public String getSbuName() {
		return sbuName;
	}
	public void setSbuName(String sbuName) {
		this.sbuName = sbuName;
	}
	public String getSbuHead() {
		return sbuHead;
	}
	public void setSbuHead(String sbuHead) {
		this.sbuHead = sbuHead;
	}
	public List<Employee> getEmplist() {
		return emplist;
	}
	public void setEmplist(List<Employee> emplist) {
		this.emplist = emplist;
	}
	
}
