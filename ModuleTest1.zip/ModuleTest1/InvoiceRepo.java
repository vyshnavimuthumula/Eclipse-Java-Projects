package com.cg.bean;

public interface InvoiceRepo {

	int saveInvoice(Invoice bean);
	
}
