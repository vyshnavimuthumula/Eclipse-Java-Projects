
public class ThreadDemo2 implements Runnable{
	ThreadDemo2(){
		Thread t = new Thread(this);
		t.start();
	}
	public void run() {
		System.out.println("hi");
	}
	public static void main(String args[]) {
		ThreadDemo2 dt = new ThreadDemo2();
	}
}
