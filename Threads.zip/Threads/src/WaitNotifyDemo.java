import java.util.*;
public class WaitNotifyDemo {
}
