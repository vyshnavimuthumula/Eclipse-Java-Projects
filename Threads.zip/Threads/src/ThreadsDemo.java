class SampleThread extends Thread{
	public void run() {
		//System.out.println("Sample Thread Run method");
		int c = 0;
		for(int i=0;i<5;i++)
			c++;
		//System.out.println(c);
		
	}
	
}
class SampleThreadImp implements Runnable{
	public void run() {
		int c1 = 0;
		for(int j=0;j<5;j++)
			c1++;
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Thread t = Thread.currentThread();
		//System.out.println("Run method " + c1);
	}
}
public class ThreadsDemo {
	public static void main(String args[]) {
		SampleThread st = new SampleThread() ;
		SampleThread st2 = new SampleThread() ;
		st.start();
		st2.start();
		SampleThreadImp sti = new SampleThreadImp() ;
		Thread t = new Thread(sti);	
		t.start();
		st.setName("vyshu");
		st.getName();
		System.out.println(st.getName());
		
}
}