
public class ThreadJoinDemo implements Runnable{
	Thread t;
	ThreadJoinDemo(String name){
		t = new Thread(this,name);
		t.start();
		try {
			t.join();
		}catch(InterruptedException e) {
			System.out.println(e);
		}
	}
	public void run() {
		System.out.println(t.getName()+"started");
		t = Thread.currentThread();
		String s=t.getName();
		System.out.println(s+"started");
		for(int i=0;i<5;i++) {
			try {
				System.out.println(Thread.currentThread().getName()+":"+i);
				Thread.sleep(1000);
			}catch(InterruptedException e) {
				System.out.println(e);
			}
		}
		System.out.println(Thread.currentThread().getName()+"end");
	}
	public static void main(String args[]) {
		ThreadJoinDemo tsdObj1 = new ThreadJoinDemo("Thread1 ");
		ThreadJoinDemo tsdObj2 = new ThreadJoinDemo("Thread2 ");
		System.out.println("main Method ends");
	}
	
}
