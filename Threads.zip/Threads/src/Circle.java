class Employee
{
String name;
int id;
public Employee() {
	// TODO Auto-generated constructor stub
}
public Employee(String name,int id)
{
this.name = name;
this.id=id;
}
}
public class Circle extends Employee
{
	Circle(){
		
	}
public static void main(String []args)
{
Manager mgr = new Manager();
}
}