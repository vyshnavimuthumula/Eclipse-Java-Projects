
class SynMethod {
	synchronized void display() {
		System.out.println(Thread.currentThread().getName());
		for(int i=0;i<5;i++) {
			System.out.println(i);
			try {
				Thread.sleep(1000);
			}catch(InterruptedException e) {
				System.out.println(e);
			}
		}
	}
}
public class SynchronizedMethodDemo implements Runnable{
	SynMethod mObj;
	SynchronizedMethodDemo(SynMethod m,String name){
		mObj=m;
		Thread t = new Thread(this,name);
		t.start();
	}
	public void run() {
		mObj.display();
	}
public static void main(String args[]) {
	SynMethod mObj = new SynMethod();
	mObj.display();
	System.out.println("hi");
	SynchronizedMethodDemo mObj1 = new SynchronizedMethodDemo(mObj,"hiii");
	mObj1.display();
	SynchronizedMethodDemo mObj2 = new SynchronizedMethodDemo(mObj,"hello");
	mObj2.display();
}
private void display() {
	// TODO Auto-generated method stub
	
}	
}
