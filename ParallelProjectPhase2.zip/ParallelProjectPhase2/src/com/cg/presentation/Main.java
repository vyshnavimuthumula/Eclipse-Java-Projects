package com.cg.presentation;

import java.util.Scanner;

import com.cg.dao.DataStorage;
import com.cg.service.Service;


public class Main {
	static Service sObj=new Service(); 
	public static void main(String[] args) {
		int n;
		Scanner sc = new Scanner(System.in);
		while(true) {
		System.out.println("***************WElCOME TO XYZ COMAPANY**************");
		System.out.println("Enter your choice");
		System.out.println("1. Create account");
		System.out.println("2. Show balance");
		System.out.println("3. Deposit");
		System.out.println("4. Withdraw");
		System.out.println("5. Fund Transfer");
		System.out.println("6. Print Transactions\n7. Exit");
		
		n = sc.nextInt();
		
		switch(n) {
		case 1:
			sObj.accountDetails();
			break;
		case 2:			
			System.out.println("Your balance is: "+sObj.showBalance());
			break;
		case 3:			
			System.out.println("Your new balance is " +sObj.dataDeposit());
			break;
		case 4:			
			sObj.withDrawal();
			break;
		case 5:			
			
			sObj.fundTrans();
			break;
		case 6:			
			sObj.printTransaction();
			break;
		case 7:
			System.exit(0);
		default:
			System.out.println("Enter valid option");
		}

	}
}
}