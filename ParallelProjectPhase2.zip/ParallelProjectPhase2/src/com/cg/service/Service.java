package com.cg.service;

import java.sql.ResultSet;
import java.util.Scanner;

import com.cg.bean.Bank;
import com.cg.dao.DataStorage;

public class Service {

	Scanner sc = new Scanner(System.in);

	DataStorage database = new DataStorage();

	DataStorage transactiondata = new DataStorage();

	public void accountDetails() {
		Bank bank = new Bank();
		System.out.print("Enter your name:");
		bank.setName(sc.next());
		System.out.print("Enter Adhaar details:");
		bank.setAdharNum(sc.next());
		System.out.print("Enter your Mobile Number:");
		bank.setPhoneNum(sc.next());
		bank.setAccnum();
		System.out.println("set the pin to the account");
		bank.setPin(sc.nextInt());
		System.out.println("Enter the amount to be deposited");
		bank.setBalance(sc.nextInt());
		System.out.println("Account created successfully");
		System.out.println("Your Account Number is: " + bank.getAccnum());
		database.storeCustomerDetails(bank);
	}

	public int showBalance() {

		int accountno;
		int pin;
		System.out.println("Enter account number");
		accountno = sc.nextInt();
		System.out.println("Enter your pin");
		pin = sc.nextInt();
		return database.showBalance(accountno);
	}

	public int dataDeposit() {
		int accountno;
		System.out.println("Enter the account no");
		accountno = sc.nextInt();
		System.out.println("Enter the amount to be depoist: ");
		int amount = sc.nextInt();
		System.out.println("Amount successfully debited");
		return database.depositAmount(accountno, amount);
	}

	public int withDrawal() {
		int accountno;
		System.out.println("Enter the account no");
		accountno = sc.nextInt();
		System.out.println("Enter the amount to be withdrawal: ");
		int amount = sc.nextInt();
		return database.withdraw(accountno, amount);

	}

	public void fundTrans() {
		
		int senderacc, receiveracc, transferamt;
		System.out.println("Enter senders account number");
		senderacc = sc.nextInt();
		System.out.println("Enter receiver account number");
		receiveracc = sc.nextInt();
		System.out.println("Enter amount to be transfer");
		transferamt = sc.nextInt();
		database.fundTransfer(senderacc, receiveracc, transferamt);
	}

	public ResultSet printTransaction() {
		int accounnum;
		System.out.println("Enter account number");
		accounnum = sc.nextInt();
		return database.getAllTransactions(accounnum);
	}

}
